const AWS = require('aws-sdk');
const ficonstype = require('file-type');
const { EndpointName } = require('./config');

const sagemakerruntime = new AWS.SageMakerRuntime();

module.exports.handler = async (event, context) => {
  const request = event.body;
  const { base64String } = request;
  const buffer = new Buffer(base64String, 'base64');
  const fileMime = ficonstype(buffer);

  console.log('fileType', fileMime.mime);
  const params = {
    Body: buffer /* Strings will be Base-64 encoded on your behalf */, /* required */
    EndpointName, /* required */
    // Accept: 'STRING_VALUE',
    ContentType: fileMime.mime,
    // CustomAttributes: 'STRING_VALUE'
  };

  const result = await sagemakerruntime.invokeEndpoint(params).promise()
    .then((res) => {
      return {
        statusCode: 200,
        result: JSON.parse(res.Body),
      }
    });

  console.log('result', result);
  return result;
};
