const config = {
  // EndpointName: 'object-detection-2018-12-10-17-11-37-210', // Old
  EndpointName: 'object-detection-2018-12-23-03-46-11-146', // New
};

module.exports = config;
