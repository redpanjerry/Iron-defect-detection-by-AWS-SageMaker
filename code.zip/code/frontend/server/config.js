const { env } = process;

const development = {
  port_http: 8080,
  host: '0.0.0.0',
  serverUrl() {
    return `http://${this.host}${this.port_http === '80' ? '' : `:${this.port_http}`}`;
  },
};

const production = {
  port_http: env.PORT || 80,
  host: env.HOST || '0.0.0.0',
  serverUrl() {
    return `http://${this.host}${this.port_http === '80' ? '' : `:${this.port_http}`}`;
  },
};

const config = {
  development,
  production,
};

export default config[env.NODE_ENV] || config.development;
