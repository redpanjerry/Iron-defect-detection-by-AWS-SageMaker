import express from 'express';
import bodyParser from 'body-parser';
import path from 'path';
import compression from 'compression';
import helmet from 'helmet';
import config from './config';

const app = express();
app.set('view engine', 'pug');
app.set('views', __dirname);

app.use(compression());
app.use(helmet());

const env = process.env.NODE_ENV;
console.log(env);
if (env === 'development') {
  const webpackMiddleware = require('webpack-dev-middleware');
  const webpackHotMiddleware = require('webpack-hot-middleware');
  const webpack = require('webpack');
  const webpackDevConfig = require('../webpack/webpack.dev.js');
  const compiler = webpack(webpackDevConfig);
  const middleware = webpackMiddleware(compiler, {
    publicPath: webpackDevConfig.output.publicPath,
    stats: { colors: true },
  });
  app.use(middleware);
  app.use(webpackHotMiddleware(compiler));
  app.use(express.static('build/client'));
  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
  });
} else {
  app.use(express.static('build/client'));
  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
  });
}

app.use(bodyParser.json());

const server = app.listen(config.port_http, config.host, () => {
  console.info('Express listening on port', config.port_http);
});

export default server;
