const path = require('path');
const fs = require('fs');
const CleanWebpackPlugin = require('clean-webpack-plugin');

const { NODE_ENV } = process.env;
module.exports = {
  mode: NODE_ENV,
  entry: './server/server.js',
  output: {
    filename: 'server.js',
    path: path.join(__dirname, '../build/server'),
    sourceMapFilename: '[name].js.map',
  },
  target: 'node',
  externals: fs.readdirSync('node_modules').reduce((acc, mod) => {
    if (mod === '.bin') {
      return acc;
    }
    acc[mod] = `commonjs ${mod}`;
    return acc;
  }, {}),
  node: {
    console: false,
    global: false,
    process: false,
    Buffer: false,
    __filename: false,
    __dirname: false,
  },
  resolve: {
    extensions: ['.js', '.json'],
  },
  devtool: 'source-map',
  module: {
    rules: [
      {
        test: /\.js$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        query: {
          presets: [
            [
              'env',
              {
                targets: { node: 7 },
                useBuiltIns: true,
              },
            ],
            'react',
            'stage-2',
          ],
        },
      },
    ],
  },
  plugins: [
    new CleanWebpackPlugin(['build/server'], {
      root: process.cwd(),
      verbose: true,
    }),
  ],
};
