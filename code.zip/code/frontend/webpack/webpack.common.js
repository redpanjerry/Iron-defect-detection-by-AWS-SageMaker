const webpack = require('webpack');
const { version } = require('../package.json');
const rules = require('./webpack.loaders');

module.exports = {
  module: {
    rules,
  },
  target: 'web',
  node: {
    fs: 'empty',
  },
  plugins: [
    new webpack.EnvironmentPlugin({
      VERSION: version,
      NODE_ENV: 'development',
    }),
  ],
};
