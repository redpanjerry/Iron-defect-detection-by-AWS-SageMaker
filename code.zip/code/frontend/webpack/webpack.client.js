const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const merge = require('webpack-merge');

const common = require('./webpack.common.js');

const { NODE_ENV } = process.env;
module.exports = merge(common, {
  mode: NODE_ENV,
  entry: './client/App.js',
  output: {
    filename: '[name].bundle.[chunkhash].js',
    path: path.resolve(__dirname, '../build/client'),
    sourceMapFilename: '[name].js.map',
    publicPath: '',
  },
  devtool: 'source-map',
  plugins: [
    new CleanWebpackPlugin(['build/client'], {
      root: process.cwd(),
      verbose: true,
    }),
    new HtmlWebpackPlugin({
      title: 'Production',
      template: './client/template.html',
      filename: 'index.html',
    }),
    new CopyWebpackPlugin([
      { from: 'client/manifest.json', to: '.' },
      { from: 'client/favicon.ico', to: '.' },
    ]),
    new webpack.LoaderOptionsPlugin({
      minimize: true,
    }),
  ],
  optimization: {
    minimizer: [
      new UglifyJsPlugin({
        cache: true,
        parallel: true,
        sourceMap: true,
      }),
      new OptimizeCSSAssetsPlugin({}),
    ],
  },
});
