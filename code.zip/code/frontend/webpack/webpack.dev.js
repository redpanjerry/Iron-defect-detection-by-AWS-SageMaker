const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const DashboardPlugin = require('webpack-dashboard/plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const merge = require('webpack-merge');

const common = require('./webpack.common.js');

const hotMiddlewareScript = 'webpack-hot-middleware/client';

module.exports = merge(common, {
  mode: 'development',
  entry: {
    bundle: [
      hotMiddlewareScript,
      './client/App.js',
    ],
  },
  output: {
    filename: '[name].js',
    path: path.join(__dirname, 'build/client'),
    sourceMapFilename: '[name].js.map',
    publicPath: '/',
    hotUpdateChunkFilename: 'hot/[id].[hash].hot-update.js',
    hotUpdateMainFilename: 'hot/[hash].hot-update.json',
  },
  devtool: 'cheap-module-eval-source-map',
  devServer: {
    hot: true,
  },
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NoEmitOnErrorsPlugin(),
    new HtmlWebpackPlugin({
      template: './client/template.html',
      filename: 'index.html',
    }),
    new DashboardPlugin(),
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NamedModulesPlugin(),
    new CopyWebpackPlugin([
      { from: 'client/manifest.json', to: '.' },
    ]),
    new webpack.LoaderOptionsPlugin({
      minimize: false,
    }),
  ],
});
