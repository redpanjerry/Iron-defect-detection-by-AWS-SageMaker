import React from 'react';
import { render } from 'react-dom';
import Loadable from 'react-loadable';
import Loading from './components/Loading';

const Demo = Loadable({
  loader: () => import('./scenes/Demo/Demo'),
  loading: Loading,
});

render(<Demo />, document.getElementById('root'));
