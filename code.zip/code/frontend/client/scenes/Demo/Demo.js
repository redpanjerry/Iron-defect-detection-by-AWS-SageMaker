import React, { Component } from 'react';
import axios from 'axios';
import {
  Row, Col, Icon, Button, Upload, Slider, Tabs, Carousel, Spin, Collapse
} from 'antd';
import Highlight from 'react-highlight';
import apiConfig from '../../apiConfig';
import 'antd/dist/antd.css';
import '../../scss/demo.scss';

const { TabPane } = Tabs;

const getBase64Image = (img) => {
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0);

  const dataURL = canvas.toDataURL('image/png', 1);
  return dataURL.replace(/^data:image\/(png|jpg);base64,/, '');
};

const predictionClassName = {
  Chinese: [
    '介在物', '黑斑', '孔蝕', '軋入鏽皮', '刮痕',
  ],
  English: [
    'inclusion', 'patches', 'pitted_surface', 'rolled-in_scale', 'scratches',
  ],
};

class Demo extends Component {
  constructor(props) {
    super(props);

    const imageNumber = 24;
    const imageList = Array(predictionClassName.Chinese.length);
    for (let i = 0; i < imageList.length; i += 1) {
      imageList[i] = Array(0);
      for (let j = 0; j < imageNumber; j += 1) {
        const fileName = `${predictionClassName.English[i]}_${60 + j}.jpg`;
        imageList[i].push(`${apiConfig.S3BucketURL}/${fileName}`);
      }
    }
    const selectedIndex = Array(predictionClassName.Chinese.length).fill(-1);
    selectedIndex[0] = 0;

    this.state = {
      selectedIndex,
      prediction: [],
      predictionText: '',
      threshold: 0.2,
      imageList,
      uploadList: [],
      imageURL: imageList[0][0],
      ratio: 0,
      translation: 0,
      imageSpinning: true,
      predictionSpinning: true
    };

    this.getLatestDetectionResult = this.getLatestDetectionResult.bind(this);

    this.renderImageTabPane = this.renderImageTabPane.bind(this);
    this.renderImageList = this.renderImageList.bind(this);
    this.renderRectangles = this.renderRectangles.bind(this);
    this.renderImageCarousel = this.renderImageCarousel.bind(this);
    this.updatePredictionText = this.updatePredictionText.bind(this);
    this.updateRatioAndTranslation = this.updateRatioAndTranslation.bind(this);

    this.currentImg = React.createRef();
    this.gutter = 0;
    this.showImageNumber = 8;
  }

  async componentDidMount() {
    document.title = 'AOI 製造業瑕疵檢測';
    this.updateRatioAndTranslation();
    window.addEventListener('resize', this.updateRatioAndTranslation);
  }

  async getLatestDetectionResult() {
    const base64 = getBase64Image(document.getElementById('image'));
    return this.setState({ prediction: [] }, () => {
      axios.post(apiConfig.getDetectionResult, { body: { base64String: base64 } })
        .then((res) => {
          const { prediction } = res.data.result;
          this.updateRatioAndTranslation();
          this.setState({ prediction }, () => {
            this.updatePredictionText();
          });
        });
    });
  }

  renderImageList(imageList, classIndex, offset) {
    const { selectedIndex } = this.state;
    return imageList.map((image, index) => (
      <Col key={image} xs={12} sm={6} md={6} lg={3} xl={3} xxl={3}>
        <button
          type="button"
          onClick={() => {
            const newSelectedIndex = Array(predictionClassName.Chinese.length).fill(-1);
            newSelectedIndex[classIndex] = index + offset;
            this.setState({
              selectedIndex: newSelectedIndex,
              imageURL: imageList[index],
              imageSpinning: true,
              predictionSpinning: true,
            });
          }}
          className="image-item"
          data-selected={selectedIndex[classIndex] === (index + offset)}
        >
          <img crossOrigin="anonymous" src={image} className="img-fluid" alt="" />
        </button>
      </Col>
    ));
  }

  renderImageCarousel(classIndex) {
    const { imageList } = this.state;
    const nowList = imageList[classIndex];

    const resultArray = Array(0);
    for (let i = 0; i < nowList.length; i += this.showImageNumber) {
      resultArray.push((
        <div>
          {this.renderImageList(
            nowList.slice(i, i + this.showImageNumber),
            classIndex,
            i,
          )}
        </div>
      ));
    }
    return resultArray;
  }

  renderImageTabPane() {
    return predictionClassName.Chinese.map((name, index) => (
      <TabPane tab={name} key={name}>
        <Carousel arrow draggable nextArrow={<Button />} prevArrow={<Button />}>
          {this.renderImageCarousel(index)}
        </Carousel>
      </TabPane>
    ));
  }

  updatePredictionText() {
    const { prediction } = this.state;

    const imgWidth = this.currentImg.current.offsetWidth;
    const imgHeight = this.currentImg.current.offsetHeight;
    let prettyText = '// 偵測結果 (瑕疵,信心,左上x,左上y,右下x,右下y)\n';
    for (let i = 0; i < prediction.length; i += 1) {
      const p = prediction[i];
      const className = predictionClassName.Chinese[p[0]];
      const confidence = p[1].toFixed(2);
      const coordinates = [
        Math.round(p[2] * imgWidth), Math.round(p[3] * imgHeight),
        Math.round(p[4] * imgWidth), Math.round(p[5] * imgHeight),
      ];
      prettyText += `['${className}', ${confidence}, ${coordinates.join(', ')}]\n`;
    }
    this.setState({ predictionText: prettyText, predictionSpinning: false });
  }

  updateRatioAndTranslation() {
    const imgWidth = this.currentImg.current.offsetWidth;
    const parentColWidth = this.currentImg.current.parentNode.clientWidth;

    this.setState({
      ratio: imgWidth / parentColWidth,
      translation: (parentColWidth - imgWidth) / 2.0 / parentColWidth,
    });
  }

  renderRectangles() {
    if (!this.currentImg.current) {
      return (<div />);
    }
    const {
      prediction, threshold, ratio, translation,
    } = this.state;

    const filteredPrediction = prediction.filter(predict => predict[1] > threshold);
    return filteredPrediction.map((predict) => {
      const name = predictionClassName.Chinese[predict[0]];
      const confidence = predict[1];
      const left = `${(predict[2] * ratio + translation) * 100}%`; // xmin
      const top = `${predict[3] * 100}%`; // ymin
      const width = `${(predict[4] - predict[2]) * ratio * 100}%`; // xmax - xmin
      const height = `${(predict[5] - predict[3]) * 100}%`; // ymax - ymin
      return (
        <div
          key={`${name}:${confidence}`}
          className="defect-rectangle defect-rectangle-m"
          style={{
            top, height, left, width,
          }}
        >
          <table className="table-naked defect-info">
            <tbody>
              <tr>
                <th>{name}</th>
                <td>{Math.round(confidence * 100) / 100}</td>
              </tr>
            </tbody>
          </table>
        </div>
      );
    });
  }

  render() {
    const {
      threshold, imageURL, uploadList, predictionText, imageSpinning, predictionSpinning,
    } = this.state;

    return (
      <div className="center" style={{ textAlign: 'center' }}>
        <h2 className="mb-3 h2 text-center font-weight-bold">
          {'AOI 製造業瑕疵檢測'}
        </h2>
        <Collapse>
          <Collapse.Panel header={'解決方案說明'}>
            <div style={{ textAlign: 'left' }}>
              瑕疵檢測是製造業中重要的環節，
              除了使用人眼檢查之外，AI 也能自動分析圖片進行檢查。
              在此以鋼鐵業為例，
              展示使用 AWS 的 AI 服務所搭建的，基於深度學習的自動瑕疵檢測方案 
              (AOI, Automatic Optical Inspection) 。
              以下整理 5 種常見的熱軋鋼鐵表面瑕疵圖，
              上傳或點選圖片後，會從雲端取得結果，並將超過信心門檻的偵測畫在圖上。
            </div>
          </Collapse.Panel>
        </Collapse>
        <Row gutter={this.gutter}>
          <Col xs={24} sm={24} md={12} lg={12} xl={12} xxl={12} className="mt-3">
            <Spin spinning={imageSpinning}>
              <img
                crossOrigin="anonymous"
                id="image"
                ref={this.currentImg}
                src={imageURL}
                className="img-fluid"
                onLoad={() => {
                  this.setState({ imageSpinning: false });
                  this.getLatestDetectionResult();
                }}
                alt=""
              />
              {this.renderRectangles()}
            </Spin>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12} xl={12} xxl={12} className="mt-3">
            <Spin spinning={predictionSpinning}>
              <Highlight className="javascript">{predictionText}</Highlight>
            </Spin>
          </Col>
        </Row>
        <Row type="flex" className="align-items-center" gutter={0}>
          <Col xs={24} sm={24} md={12} lg={12} xl={12} xxl={12} className="mt-3">
            <Button href={apiConfig.imageSetDownloadURL} style={{ marginRight: '5px' }}>
              <Icon type="download" />
              {'下載測試圖片'}
            </Button>
            <Upload
              fileList={uploadList}
              onChange={() => { this.setState({ uploadList: [] }); }}
              beforeUpload={(file) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = (e) => {
                  const base64 = e.target.result;
                  this.setState({
                    imageURL: base64, imageSpinning: true, predictionSpinning: true,
                  });
                };
                return false;
              }}
              name="photo"
              listType="picture"
            >
              <Button type="primary">
                <Icon type="upload" />
                {'上傳'}
              </Button>
            </Upload>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12} xl={12} xxl={12} className="mt-3">
            {'信心門檻'}
            <Slider
              defaultValue={0.2}
              min={0}
              max={1}
              step={0.01}
              marks={{ 0: '0', 0.5: '0.5', 1: '1' }}
              value={threshold}
              onChange={(value) => { this.setState({ threshold: value }); }}
            />
          </Col>
        </Row>
        <Row
          gutter={{
            xs: 8, sm: 16, md: 24, lg: 32, xl: 40, xxl: 48,
          }}
          className="mt-3 mb-3"
        >
          <Tabs defaultActiveKey="0">
            {this.renderImageTabPane()}
          </Tabs>
        </Row>
      </div>
    );
  }
}

export default Demo;
