import React from 'react';
import loadingImg from '../assets/Spinner-0.7s-200px.svg';

const Loading = () => (
  <div
    className="center align-items-center justify-content-center"
    style={{
      height: '100%',
      width: '100%',
      display: 'flex',
    }}
  >
    <img
      src={loadingImg}
      alt="Loading"
      style={{ width: '100vmin', height: '100vmin' }}
    />
  </div>
);

export default Loading;
