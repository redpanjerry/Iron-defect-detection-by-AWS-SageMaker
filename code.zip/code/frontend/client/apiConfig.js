const apiConfig = {
  getDetectionResult: 'https://q6j1somacd.execute-api.ap-northeast-1.amazonaws.com/beta/invoke-sagemaker',
  imageSetDownloadURL: 'https://s3-us-west-2.amazonaws.com/sagemaker-ecv/DEMO-ObjectDetection/validation/test_images.zip',
  S3BucketURL: 'https://s3-us-west-2.amazonaws.com/sagemaker-ecv/DEMO-ObjectDetection/validation'
};

export default apiConfig;
